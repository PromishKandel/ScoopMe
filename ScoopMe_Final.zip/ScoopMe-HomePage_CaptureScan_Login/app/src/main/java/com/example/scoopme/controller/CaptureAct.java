package com.example.scoopme.controller;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity {
    //Don't have to implement anything here since capture activity has everything built in
}
