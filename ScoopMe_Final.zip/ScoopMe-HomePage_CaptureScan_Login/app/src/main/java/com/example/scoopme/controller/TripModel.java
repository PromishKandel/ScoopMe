package com.example.scoopme.controller;

import java.util.ArrayList;
import java.util.Arrays;

public class TripModel {
    private ArrayList<Matchmodel> match;
    private String start;
    private ArrayList<JSONExtractor> info;

}
